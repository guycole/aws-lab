#!/bin/bash
#
# Title:pytest.sh
#
# Description:
#
# Development Environment: OSX 10.10.5
#
export PYTHONPATH=/Users/gsc/IdeaProjects/aws-lab/build1/src/main/python/demo_py
#
/opt/local/Library/Frameworks/Python.framework/Versions/2.7/bin/py.test
#
