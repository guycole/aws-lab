#! /usr/bin/python
#
# Title:target.py
# Description:
# Development Environment:OS X 10.13.3/Python 2.7.7
# Author:G.S. Cole (guycole at gmail dot com)
#

class Target:

    def __init__(self):
        print 'init noted for target'

    def adder(self, arg1, arg2):
        return arg1 + arg2;